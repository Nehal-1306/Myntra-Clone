// The product list is stored as simple JavaScript objects.
const products = [
  {
    id: 1,
    brand: "Roadster",
    name: "Denim Detail Casual Jacket",
    category: "Women",
    price: 1499,
    originalPrice: 2999,
    discount: 50,
    image:
      "https://images.unsplash.com/photo-1786632482411-f9a4ab9536dc?crop=entropy&cs=tinysrgb&fit=crop&fm=jpg&q=80&w=700",
  },
  {
    id: 2,
    brand: "Moda Rapido",
    name: "Classic Black Party Dress",
    category: "Women",
    price: 1799,
    originalPrice: 2999,
    discount: 40,
    image:
      "https://images.unsplash.com/photo-1779406273900-a1b06ffafb10?crop=entropy&cs=tinysrgb&fit=crop&fm=jpg&q=80&w=700",
  },
  {
    id: 3,
    brand: "Highlander",
    name: "Relaxed Studio Shirt",
    category: "Men",
    price: 999,
    originalPrice: 1999,
    discount: 50,
    image:
      "https://images.unsplash.com/photo-1779282525914-862151c52df2?crop=entropy&cs=tinysrgb&fit=crop&fm=jpg&q=80&w=700",
  },
  {
    id: 4,
    brand: "DressBerry",
    name: "Statement Pink Occasion Dress",
    category: "Women",
    price: 2199,
    originalPrice: 3999,
    discount: 45,
    image:
      "https://images.unsplash.com/photo-1779153457080-687617be8643?crop=entropy&cs=tinysrgb&fit=crop&fm=jpg&q=80&w=700",
  },
  {
    id: 5,
    brand: "H&M",
    name: "Kids Weekend Outfit Set",
    category: "Kids",
    price: 899,
    originalPrice: 1499,
    discount: 40,
    image:
      "https://images.unsplash.com/photo-1771919358565-059d9348b50b?crop=entropy&cs=tinysrgb&fit=crop&fm=jpg&q=80&w=700",
  },
  {
    id: 6,
    brand: "Anouk",
    name: "Monochrome Evening Dress",
    category: "Women",
    price: 1899,
    originalPrice: 3799,
    discount: 50,
    image:
      "https://images.unsplash.com/photo-1779398970408-1454e2a126c2?crop=entropy&cs=tinysrgb&fit=crop&fm=jpg&q=80&w=700",
  },
  {
    id: 7,
    brand: "Mast & Harbour",
    name: "Premium Lounge Throw",
    category: "Home",
    price: 1299,
    originalPrice: 1999,
    discount: 35,
    image:
      "https://images.unsplash.com/photo-1792058630298-3f1350378549?crop=entropy&cs=tinysrgb&fit=crop&fm=jpg&q=80&w=700",
  },
  {
    id: 8,
    brand: "Lakmé",
    name: "Everyday Glam Beauty Edit",
    category: "Beauty",
    price: 699,
    originalPrice: 999,
    discount: 30,
    image:
      "https://images.unsplash.com/photo-1646105659698-1389145bf6a0?crop=entropy&cs=tinysrgb&fit=crop&fm=jpg&q=80&w=700",
  },
  {
    id: 9,
    brand: "Wrogn",
    name: "Smart Black Tailored Suit",
    category: "Men",
    price: 2599,
    originalPrice: 3999,
    discount: 35,
    image:
      "https://images.unsplash.com/photo-1776273920157-4d604bff2cba?crop=entropy&cs=tinysrgb&fit=crop&fm=jpg&q=80&w=700",
  },
  {
    id: 10,
    brand: "Tokyo Talkies",
    name: "Faux Fur Winter Jacket",
    category: "Women",
    price: 1999,
    originalPrice: 3999,
    discount: 50,
    image:
      "https://images.unsplash.com/photo-1771012265743-199b156327cb?crop=entropy&cs=tinysrgb&fit=crop&fm=jpg&q=80&w=700",
  },
];

// Find the HTML elements that JavaScript needs to update.
const productGrid = document.getElementById("productGrid");
const productCount = document.getElementById("productCount");
const searchInput = document.getElementById("searchInput");
const categoryButtons = document.querySelectorAll(".category-link");
const emptyProducts = document.getElementById("emptyProducts");
const clearFiltersButton = document.getElementById("clearFiltersButton");
const bagCount = document.getElementById("bagCount");
const bagItems = document.getElementById("bagItems");
const bagTotal = document.getElementById("bagTotal");
const bagDrawer = document.getElementById("bagDrawer");
const drawerOverlay = document.getElementById("drawerOverlay");
const openBagButton = document.getElementById("openBagButton");
const closeBagButton = document.getElementById("closeBagButton");
const checkoutButton = document.getElementById("checkoutButton");
const menuButton = document.getElementById("menuButton");
const categoryMenu = document.getElementById("categoryMenu");
const toast = document.getElementById("toast");

let selectedCategory = "All";
let toastTimer;

// Read the saved bag. If there is no saved bag, begin with an empty array.
let shoppingBag = JSON.parse(localStorage.getItem("styleKartBag")) || [];

function formatPrice(price) {
  return `₹${price.toLocaleString("en-IN")}`;
}

// Create a simple built-in fallback image when an online photo cannot load.
function createFallbackImage() {
  const fallbackSvg = `
    <svg xmlns="http://www.w3.org/2000/svg" width="600" height="800">
      <rect width="100%" height="100%" fill="#fff0f4"/>
      <text x="50%" y="48%" text-anchor="middle" fill="#ff3f6c"
        font-family="Arial" font-size="42" font-weight="bold">StyleKart</text>
      <text x="50%" y="55%" text-anchor="middle" fill="#726f79"
        font-family="Arial" font-size="22">Image unavailable</text>
    </svg>`;

  return `data:image/svg+xml;charset=UTF-8,${encodeURIComponent(fallbackSvg)}`;
}

function addImageFallbacks() {
  document.querySelectorAll("img").forEach((image) => {
    image.addEventListener(
      "error",
      () => {
        image.src = createFallbackImage();
      },
      { once: true },
    );
  });
}

// Build and display the product cards.
function displayProducts(productList) {
  productGrid.innerHTML = "";

  productList.forEach((product) => {
    const productCard = document.createElement("article");
    productCard.className = "product-card";

    productCard.innerHTML = `
      <div class="product-image-wrap">
        <img class="product-image" src="${product.image}" alt="${product.name}" loading="lazy">
        <span class="discount-badge">${product.discount}% OFF</span>
      </div>
      <div class="product-info">
        <h3 class="product-brand">${product.brand}</h3>
        <p class="product-name">${product.name}</p>
        <div class="price-row">
          <span class="current-price">${formatPrice(product.price)}</span>
          <span class="original-price">${formatPrice(product.originalPrice)}</span>
          <span class="price-discount">(${product.discount}% off)</span>
        </div>
        <button class="add-button" type="button" data-product-id="${product.id}">
          Add to Bag
        </button>
      </div>
    `;

    productGrid.appendChild(productCard);
  });

  productCount.textContent = `${productList.length} ${productList.length === 1 ? "style" : "styles"}`;
  emptyProducts.classList.toggle("hidden", productList.length !== 0);
  productGrid.classList.toggle("hidden", productList.length === 0);

  document.querySelectorAll(".add-button").forEach((button) => {
    button.addEventListener("click", () => {
      addToBag(Number(button.dataset.productId));
    });
  });

  addImageFallbacks();
}

// Search and category filters work together.
function filterProducts() {
  const searchText = searchInput.value.trim().toLowerCase();

  const filteredProducts = products.filter((product) => {
    const matchesSearch =
      product.name.toLowerCase().includes(searchText) ||
      product.brand.toLowerCase().includes(searchText);
    const matchesCategory =
      selectedCategory === "All" || product.category === selectedCategory;

    return matchesSearch && matchesCategory;
  });

  displayProducts(filteredProducts);
}

function saveBag() {
  localStorage.setItem("styleKartBag", JSON.stringify(shoppingBag));
}

function showToast(message) {
  toast.textContent = message;
  toast.classList.add("show");
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => toast.classList.remove("show"), 1800);
}

function addToBag(productId) {
  const existingItem = shoppingBag.find((item) => item.id === productId);

  if (existingItem) {
    existingItem.quantity += 1;
  } else {
    shoppingBag.push({ id: productId, quantity: 1 });
  }

  saveBag();
  displayBag();
  showToast("Added to your bag");
}

function removeFromBag(productId) {
  shoppingBag = shoppingBag.filter((item) => item.id !== productId);
  saveBag();
  displayBag();
}

// Update the drawer, total price, and navbar count.
function displayBag() {
  bagItems.innerHTML = "";
  let totalPrice = 0;
  let totalItems = 0;

  shoppingBag.forEach((bagItem) => {
    const product = products.find((item) => item.id === bagItem.id);

    // Ignore a saved item if its product no longer exists.
    if (!product) return;

    totalPrice += product.price * bagItem.quantity;
    totalItems += bagItem.quantity;

    const bagItemElement = document.createElement("article");
    bagItemElement.className = "bag-item";
    bagItemElement.innerHTML = `
      <img src="${product.image}" alt="${product.name}">
      <div class="bag-item-info">
        <h3>${product.brand}</h3>
        <p>${product.name}</p>
        <strong>
          ${formatPrice(product.price * bagItem.quantity)}
          <span class="quantity">Qty: ${bagItem.quantity}</span>
        </strong>
      </div>
      <button class="remove-button" type="button" data-remove-id="${product.id}"
        aria-label="Remove ${product.name} from bag">×</button>
    `;
    bagItems.appendChild(bagItemElement);
  });

  if (totalItems === 0) {
    bagItems.innerHTML = `
      <div class="empty-bag">
        <div class="empty-bag-symbol">S</div>
        <h3>Your bag is empty</h3>
        <p>Add something stylish and it will appear here.</p>
      </div>
    `;
  }

  bagCount.textContent = totalItems;
  bagTotal.textContent = formatPrice(totalPrice);
  checkoutButton.disabled = totalItems === 0;

  document.querySelectorAll(".remove-button").forEach((button) => {
    button.addEventListener("click", () => {
      removeFromBag(Number(button.dataset.removeId));
    });
  });

  addImageFallbacks();
}

function openBag() {
  bagDrawer.classList.add("open");
  drawerOverlay.classList.add("open");
  bagDrawer.setAttribute("aria-hidden", "false");
  document.body.classList.add("drawer-open");
  closeBagButton.focus();
}

function closeBag() {
  bagDrawer.classList.remove("open");
  drawerOverlay.classList.remove("open");
  bagDrawer.setAttribute("aria-hidden", "true");
  document.body.classList.remove("drawer-open");
}

// Event listeners run functions when the visitor interacts with the page.
searchInput.addEventListener("input", filterProducts);

categoryButtons.forEach((button) => {
  button.addEventListener("click", () => {
    selectedCategory = button.dataset.category;

    categoryButtons.forEach((item) => item.classList.remove("active"));
    button.classList.add("active");
    categoryMenu.classList.remove("open");
    menuButton.setAttribute("aria-expanded", "false");

    filterProducts();
  });
});

clearFiltersButton.addEventListener("click", () => {
  searchInput.value = "";
  selectedCategory = "All";
  categoryButtons.forEach((button) => {
    button.classList.toggle("active", button.dataset.category === "All");
  });
  filterProducts();
});

menuButton.addEventListener("click", () => {
  const menuIsOpen = categoryMenu.classList.toggle("open");
  menuButton.setAttribute("aria-expanded", String(menuIsOpen));
});

openBagButton.addEventListener("click", openBag);
closeBagButton.addEventListener("click", closeBag);
drawerOverlay.addEventListener("click", closeBag);

document.addEventListener("keydown", (event) => {
  if (event.key === "Escape") {
    closeBag();
    categoryMenu.classList.remove("open");
    menuButton.setAttribute("aria-expanded", "false");
  }
});

checkoutButton.addEventListener("click", () => {
  showToast("Checkout is ready for the next lesson!");
});

// Show products and any saved bag items when the page first opens.
displayProducts(products);
displayBag();
